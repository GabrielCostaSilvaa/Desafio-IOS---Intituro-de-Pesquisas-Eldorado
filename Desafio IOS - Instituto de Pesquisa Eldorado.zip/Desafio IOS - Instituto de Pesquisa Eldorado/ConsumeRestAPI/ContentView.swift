import SwiftUI

struct ContentView: View{

    @State var api = [Api]()

     var body: some View {
        List(api) { Api in
            
            VStack(alignment: .leading) {
                
                Text("\(api.title)")
                    .font(.title)
                    .foregroundColor(.red)
                    .padding(.bottom)
                
                
                HStack{
                    Text("\(api.author)")
                        .font(.body)
                        .fontWeight(.bold)
                        
                }
                Spacer()
            }
            
        }
            .onAppear() {
                Api().loadData { (api) in
                    self.api = api
                }
            }.navigationTitle("Api List")
    }
}

struct ContentView_Previews: PreviewProvider{
    static var previews: some View{
        ContentView()
    }
}