import SwiftUI

@main
struct ConsumeRestApi: app {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}