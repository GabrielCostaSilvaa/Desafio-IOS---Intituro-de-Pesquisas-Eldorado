import UIKit

struct AtributoInfo: Codable, Identifiable {
    let current_user_url: String
    let current_user_authorizations_html_url: String
    let authorizations_url: String
    let code_search_url: String
    let commit_search_url: String
    let emails_url: String
    let emojis_url: String
    let events_url: String
    let feeds_url: String
    let followers_url: String
    let following_url: String
    let gists_url: String
    let hub_url: String
    let issue_search_url: String
    let issues_url: String
    let keys_url: String
    let label_search_url: String
    let notifications_url: String
    let organization_url: String
    let organization_repositories_url: String
    let organization_teams_url: String
    let public_gists_url: String
    let rate_limit_url: String
    let repository_url: String
    let repository_search_url: String
    let current_user_repositories_url: String
    let rate_limit_url: String
    let repository_url: String
    let repository_search_url: String
    let current_user_repositories_url: String
    let starred_url: String
    let starred_gists_url: String
    let topic_search_url: String
    let user_url: String
    let user_organizations_url: String
    let user_repositories_url: String
    let user_search_url: String
}

struct Response: Codable, Identifiable {
    let current_user_url: String
    let current_user_authorizations_html_url: String
    let authorizations_url: String
    let code_search_url: String
    let commit_search_url: String
    let emails_url: String
    let emojis_url: String
    let events_url: String
    let feeds_url: String
    let followers_url: String
    let following_url: String
    let gists_url: String
    let hub_url: String
    let issue_search_url: String
    let issues_url: String
    let keys_url: String
    let label_search_url: String
    let notifications_url: String
    let organization_url: String
    let organization_repositories_url: String
    let organization_teams_url: String
    let public_gists_url: String
    let rate_limit_url: String
    let repository_url: String
    let repository_search_url: String
    let current_user_repositories_url: String
    let rate_limit_url: String
    let repository_url: String
    let repository_search_url: String
    let current_user_repositories_url: String
    let starred_url: String
    let starred_gists_url: String
    let topic_search_url: String
    let user_url: String
    let user_organizations_url: String
    let user_repositories_url: String
    let user_search_url: String

    let atributoInfo: AtributoInfo
}

if let url = URL(String: "https://api.github.com"){
    URLSession.shared.dataTask(with: url){data, response, error in}
        if let data =  data{
            do{
                let res = try JSONDecoder().decode(Response.self, from data)
            } catch let error{
                print(error)
            }
        }
    }.resume()
}